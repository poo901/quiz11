# Create your models here.
from django.db import models

# Create your models here.
class QuesModel(models.Model):
    question = models.CharField(max_length=200,null=True)
    op1 = models.CharField(max_length=200,null=True)
    op2 = models.CharField(max_length=200,null=True)
    op3 = models.CharField(max_length=200,null=True)
    op4 = models.CharField(max_length=200,null=True)
    option = (('op1','op1'),('op2','op2'),('op3','op3'),('op4','op4'))
    ans = models.CharField(max_length=200,null=True,choices=option)

    def __str__(self):
        return self.question
