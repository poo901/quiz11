from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from testapp.forms import SignUpForm,addQuestionform
from django.http import HttpResponse
from testapp.models import QuesModel


# Create your views here.
def home_view(request):
    return render(request,'testapp/home.html')


@login_required
def Quiz1_view(request):
    add=addQuestionform()
    if request.method == 'POST':
        add = addQuestionform(request.POST)
        if add.is_valid():
            add.save()
    return render(request,'testapp/quiz.html',{'add':add})

def login_view(request):
    return render (request,'testapp/login.html')

def logout_view(request):
    return render(request,'testapp/logout.html')

def signup_view(request):
    form=SignUpForm()
    if request.method=="POST":
        form=SignUpForm(request.POST)
        if form.is_valid():
            user=form.save()
            return HttpResponseRedirect('/accounts/login')
    return render(request,'testapp/signup.html',{'form':form})

def exam_view(request):
    quest = QuesModel.objects.all()
    return render(request,'testapp/exam.html',{'quest':quest})

def result_view(request):
    return render(request,'testapp/result.html')
