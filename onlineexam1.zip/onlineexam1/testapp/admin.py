from django.contrib import admin
from testapp.models import QuesModel

# Register your models here.
admin.site.register(QuesModel)
